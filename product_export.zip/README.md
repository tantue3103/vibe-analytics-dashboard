# Data Analytics Dashboard - Product Index

This directory contains the full source code for the Streamlit Data Analytics Dashboard.

## File Index
1. **`app.py`** 
   - The core Python application file. Contains the entire Streamlit dashboard UI, comparative logic, and visualization generation scripts.
2. **`requirements.txt`**
   - The dependencies manifest detailing the exact Python libraries (pandas, streamlit, seaborn, matplotlib, sqlalchemy) required to run the environment locally.
3. **`product_export.zip`**
   - A compressed archive containing the entire application for easy distribution or emailing.

## How to Run:
1. Ensure Python is installed on your computer.
2. Open your terminal in this directory.
3. Run `pip install -r requirements.txt`.
4. Run `python -m streamlit run app.py`.
