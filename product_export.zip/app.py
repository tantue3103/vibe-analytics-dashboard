import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine

st.set_page_config(page_title="Data Analytics Dashboard", layout="wide")

@st.cache_data
def clean_data(df):
    """Data cleaning pipeline"""
    initial_count = len(df)
    
    # Trim spaces for all string columns
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = df[col].str.strip()
            
    # Remove duplicates based on company
    if 'company' in df.columns:
        df = df.drop_duplicates(subset=['company'])
    dropped_count = initial_count - len(df)
    
    # Normalize industry names
    if 'industry' in df.columns:
        df['industry'] = df['industry'].str.title()
        
    return df, dropped_count

st.title("📊 Data Analytics Dashboard")
st.markdown("Upload multiple CSV files to analyze individually or compare against each other.")

# We accept multiple files now
uploaded_files = st.file_uploader("Upload CSV files (Expected columns: company, industry, address, phone, email)", type=["csv"], accept_multiple_files=True)

if 'datasets' not in st.session_state:
    st.session_state['datasets'] = {}

if uploaded_files:
    # 1. Load Data
    current_filenames = [f.name for f in uploaded_files]
    
    # Process only newly uploaded ones
    for uploaded_file in uploaded_files:
        if uploaded_file.name not in st.session_state['datasets']:
            with st.spinner(f"Reading and analyzing {uploaded_file.name}..."):
                try:
                    df = pd.read_csv(uploaded_file)
                    # Strip whitespace from column names and make lowercase
                    df.columns = [str(col).strip().lower() for col in df.columns]
                    
                    required_cols = ['company', 'industry', 'address', 'phone', 'email']
                    missing_cols = [col for col in required_cols if col not in df.columns]
                    
                    if missing_cols:
                        st.error(f"'{uploaded_file.name}' is missing columns: {', '.join(missing_cols)}")
                    else:
                        clean_df, dropped_count = clean_data(df)
                        st.session_state['datasets'][uploaded_file.name] = {
                            'data': clean_df,
                            'dropped': dropped_count
                        }
                        st.toast(f"Successfully processed {uploaded_file.name}!", icon="✅")
                except Exception as e:
                    st.error(f"Error reading {uploaded_file.name}: {e}")
                    
    # Clean up state if file was removed from uploader
    for name in list(st.session_state['datasets'].keys()):
        if name not in current_filenames:
            del st.session_state['datasets'][name]

if len(st.session_state['datasets']) > 0:
    datasets = st.session_state['datasets']
    
    # --- UI Layout Tabs ---
    tab1, tab2 = st.tabs(["📊 Single File Analysis", "⚖️ Compare Datasets"])
    
    # ==========================
    # TAB 1: Single File Analysis
    # ==========================
    with tab1:
        st.subheader("Explore a Single Dataset")
        selected_file = st.selectbox("Select a file to analyze", options=list(datasets.keys()))
        
        if selected_file:
            df = datasets[selected_file]['data']
            dropped_count = datasets[selected_file]['dropped']
            
            # Count number of companies by industry
            industry_counts = df['industry'].value_counts()
            top_5_industries = industry_counts.head(5)
            
            missing_phone = df['phone'].isna() | (df['phone'] == '')
            missing_email = df['email'].isna() | (df['email'] == '')
            missing_data_mask = missing_phone | missing_email
            missing_data = df[missing_data_mask]
            
            st.header("Overview")
            
            # Automated Single File Insights
            total_companies = len(df)
            if len(industry_counts) > 0:
                top_industry = industry_counts.index[0]
                top_count = industry_counts.values[0]
                top_percentage = (top_count / total_companies) * 100
                if len(industry_counts) > 1:
                    second_industry = industry_counts.index[1]
                    second_count = industry_counts.values[1]
                    dominance_gap = top_count - second_count
                    insight_text = f"**{top_industry}** is the dominant industry here, accounting for **{top_percentage:.1f}%** ({top_count}) of the companies. It leads the second most common industry ({second_industry}) by a margin of {dominance_gap} companies. This dominance suggests that the dataset was likely sourced from platforms or networks heavily focused on the {top_industry} sector."
                else:
                    insight_text = f"The dataset consists entirely of companies in the **{top_industry}** industry."
            else:
                insight_text = "Not enough data to calculate industry insights."
                
            st.info(f"💡 **Automated Insight:** {insight_text}")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Companies", len(df), delta=f"-{dropped_count} duplicates" if dropped_count > 0 else None, delta_color="normal")
            with col2:
                st.metric("Unique Industries", len(industry_counts))
            with col3:
                st.metric("Records Missing Contact Info", len(missing_data))
                
            st.divider()
            
            col_chart, col_top5 = st.columns([2, 1])
            with col_chart:
                st.subheader("Industry Distribution")
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.barplot(x=industry_counts.values, y=industry_counts.index, ax=ax, palette="viridis", hue=industry_counts.index, legend=False)
                ax.set_xlabel("Number of Companies")
                ax.set_ylabel("Industry")
                ax.set_title("Companies per Industry")
                for i, v in enumerate(industry_counts.values):
                    ax.text(v + 0.1, i, str(v), color='black', va='center')
                plt.tight_layout()
                st.pyplot(fig)
                
            with col_top5:
                st.subheader("Top 5 Industries")
                top_5_df = top_5_industries.reset_index().rename(columns={'count': 'Companies', 'industry': 'Industry'})
                st.dataframe(top_5_df, hide_index=True, use_container_width=True)
                
            st.divider()
            st.subheader("Missing Contact Information")
            if len(missing_data) > 0:
                st.write("The following companies are missing either a phone number or an email address:")
                st.dataframe(missing_data[['company', 'industry', 'phone', 'email']], hide_index=True, use_container_width=True)
            else:
                st.success("🎉 All companies have both phone and email information!")
                
            with st.expander("View Cleaned Raw Data"):
                st.dataframe(df, hide_index=True, use_container_width=True)
                
            st.divider()
            st.subheader("💾 Save to PostgreSQL")
            st.markdown("Enter your PostgreSQL database credentials below to save the cleaned data.")
            with st.form("db_form"):
                col_db1, col_db2 = st.columns(2)
                with col_db1:
                    db_host = st.text_input("Host", "localhost")
                    db_port = st.text_input("Port", "5432")
                    db_user = st.text_input("Username", "postgres")
                with col_db2:
                    db_password = st.text_input("Password", type="password")
                    db_name = st.text_input("Database Name", "postgres")
                    table_name = st.text_input("Table Name", "companies")
                save_button = st.form_submit_button("Save Data to Database")
                
                if save_button:
                    if not db_password:
                        st.error("Please provide a password for your database user.")
                    else:
                        try:
                            conn_str = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
                            engine = create_engine(conn_str)
                            with st.spinner("Saving data to PostgreSQL..."):
                                df.to_sql(table_name, engine, if_exists='replace', index=False)
                            st.success(f"🎉 Successfully saved {len(df)} records to table '{table_name}'!")
                        except Exception as e:
                            st.error(f"Failed to save data: {e}")

    # ==========================
    # TAB 2: Compare Datasets
    # ==========================
    with tab2:
        if len(datasets) < 2:
            st.info("Upload at least **two files** using the uploader above to use the comparison feature.")
        else:
            st.subheader("Dataset A/B Comparison")
            colA, colB = st.columns(2)
            with colA:
                file_a_name = st.selectbox("Select Baseline Dataset (File A)", options=list(datasets.keys()), index=0)
            with colB:
                file_b_name = st.selectbox("Select Comparison Dataset (File B)", options=list(datasets.keys()), index=1 if len(datasets) > 1 else 0)
                
            if file_a_name == file_b_name:
                st.warning("Please select two different files to compare.")
            else:
                df_a = datasets[file_a_name]['data']
                df_b = datasets[file_b_name]['data']
                
                # --- Set Differences Logic ---
                companies_a = set(df_a['company'])
                companies_b = set(df_b['company'])
                
                common = companies_a.intersection(companies_b)
                missing = companies_a - companies_b # Present in A, missing from B
                new = companies_b - companies_a # Present in B, missing from A
                
                st.header("1. High-Level Delta")
                m1, m2, m3, m4 = st.columns(4)
                m1.metric(f"Total in {file_a_name}", len(df_a))
                m2.metric(f"Total in {file_b_name}", len(df_b), delta=len(df_b)-len(df_a))
                m3.metric("New Companies in B", len(new), delta_color="normal")
                m4.metric("Missing Companies in B", len(missing), delta_color="inverse")
                
                # --- Comparative Insights ---
                st.subheader("💡 Analysis & Insights on Differences")
                
                insight_str = ""
                # Growth insight
                if len(new) > len(missing):
                    insight_str += f"- **Platform Expansion:** File B contains **{len(new)} new companies** that were not present in File A, representing an expansion or newer extraction effort. \n"
                elif len(missing) > len(new):
                    insight_str += f"- **Dataset Contraction:** File B is missing **{len(missing)} companies** that were present in File A, indicating potential churn, strict filtering criteria, or a narrower data focus. \n"
                else:
                    insight_str += f"- **Consistent Volume:** Both datasets have a consistent overall volume, though the specific companies present may vary slightly. \n"
                
                # Distribution shift insight
                ind_a = df_a['industry'].value_counts()
                ind_b = df_b['industry'].value_counts()
                top_a = ind_a.index[0] if not ind_a.empty else None
                top_b = ind_b.index[0] if not ind_b.empty else None
                
                if top_a != top_b and top_a and top_b:
                    insight_str += f"- **Major Industry Shift:** The dominant industry shifted drastically from **{top_a}** in File A to **{top_b}** in File B, suggesting entirely different data targets between the two datasets."
                elif top_a:
                    diff_vol = (ind_b.get(top_a, 0) - ind_a.get(top_a, 0))
                    insight_str += f"- **Stable Core Market:** **{top_a}** remains the dominant industry across both files (change of {diff_vol} records). "
                    
                st.info(insight_str)
                
                # --- Visual Distributions ---
                st.header("2. Industry Distribution Differences")
                ind_df = pd.DataFrame({'File A': ind_a, 'File B': ind_b}).fillna(0)
                
                fig2, ax2 = plt.subplots(figsize=(12, 6))
                ind_df.plot(kind='bar', ax=ax2, color=['#1f77b4', '#ff7f0e'])
                ax2.set_xlabel("Industry")
                ax2.set_ylabel("Number of Companies")
                ax2.set_title(f"Industry Comparison")
                plt.xticks(rotation=45, ha='right')
                plt.tight_layout()
                st.pyplot(fig2)
                
                # --- Field Level Delta (Phone / Email) ---
                st.header("3. Field Level Changes")
                st.markdown("Analyzing contact info changes for companies present in **both** datasets.")
                
                merged = df_a.merge(df_b, on='company', suffixes=('_A', '_B'), how='inner')
                merged['phone_changed'] = (merged['phone_A'].fillna('') != merged['phone_B'].fillna(''))
                merged['email_changed'] = (merged['email_A'].fillna('') != merged['email_B'].fillna(''))
                
                changed_df = merged[merged['phone_changed'] | merged['email_changed']]
                
                if len(changed_df) > 0:
                    st.write(f"⚠️ Found {len(changed_df)} common companies with updated phone or email data:")
                    display_cols = ['company', 'phone_A', 'phone_B', 'email_A', 'email_B']
                    st.dataframe(changed_df[display_cols], use_container_width=True, hide_index=True)
                else:
                    st.success("✅ No updates to phone or email fields for any common companies!")
                    
                # --- Breakdown Tables ---
                st.header("4. Missing & New Companies Registry")
                col_new, col_miss = st.columns(2)
                with col_new:
                    st.subheader(f"✨ New in {file_b_name}")
                    if len(new) > 0:
                        st.dataframe(df_b[df_b['company'].isin(new)], use_container_width=True, hide_index=True)
                    else:
                        st.write("None")
                with col_miss:
                    st.subheader(f"❌ Missing from {file_b_name}")
                    if len(missing) > 0:
                        st.dataframe(df_a[df_a['company'].isin(missing)], use_container_width=True, hide_index=True)
                    else:
                        st.write("None")
